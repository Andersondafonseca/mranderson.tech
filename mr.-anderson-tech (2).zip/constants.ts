
// Navigation and Social links are now fetched from the CMS.
// This file can be used for any remaining constants that are not managed by the CMS.
